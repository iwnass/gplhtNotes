style
app
index
server
admin js
admin html